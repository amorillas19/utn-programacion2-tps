/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_parcial_2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author enfer
*/
public class Academia {
    private int id;
    private String nombre;
    private String direccion;
    private List<Curso> cursos= new ArrayList();
    private List<Instructor> instructores=new ArrayList();
    
    public Academia(int id, String nombre, String direccion) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public List<Curso> getCursos() {
        return cursos;
    }

    public void addCurso(Curso curso){
        if(curso!=null){
        cursos.add(curso);
        curso.setAcademia(this);  
        }
    }
    
    public void removeCurso(Curso curso){
        cursos.remove(curso);
        curso.setAcademia(null);

    }
    
    public void addInstructor(Instructor ins){
        if(ins!=null){
            instructores.add(ins);
        }
    }
    
    public void remove(Instructor ins){
    
        instructores.remove(ins);
    }

    public List<Instructor> getInstructores() {
        return instructores;
    }

    @Override
    public String toString() {
        return "Academia{" + "id=" + id + ", nombre=" + nombre + ", direccion=" + direccion + ", cursos=" + cursos + ", instructores=" + instructores + '}';
    }

   
    
    
}
