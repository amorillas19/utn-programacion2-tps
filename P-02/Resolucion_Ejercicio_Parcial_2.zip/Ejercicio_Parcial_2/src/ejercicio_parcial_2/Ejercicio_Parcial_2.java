/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_parcial_2;



/**
 *
 * @author enfer
 */
public class Ejercicio_Parcial_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Academia a= new Academia(1,"UTN","Berutti 2686");
        Instructor i1= new Instructor(2,"Ariel","enferrelariel@hotmail.com",EspecialidadInstructor.PROGRAMACION);
        Instructor i2= new Instructor(3,"Giuliano","giuliano@hotmail.com",EspecialidadInstructor.DISEÑO);
        
        a.addInstructor(i1);
        a.addInstructor(i2);
        
        Curso c1= new Curso(4,"Programacion 2",140,NivelCurso.INTERMEDIO);
        Curso c2= new Curso(5,"Programacion 1",140,NivelCurso.BASICO);
        Curso c3= new Curso(6,"Programacion 3",140,NivelCurso.AVANZADO);
        
        a.addCurso(c3);
        a.addCurso(c2);
        a.addCurso(c1);
        
        c1.addModulo(7,"Herencia", "Herencia, DownCasting, UpCasting");
        
        c2.addModulo(8,"Repetitivas", "For, While");
        c3.addModulo(9,"Fundamentos de SpringBoots", "IOstarter, Protocolo HTTP");
        
        Estudiante e1= new Estudiante(10, "Carlos","carlos@gmail.com");
        
        Inscripcion ins1= new Inscripcion(11);
        Inscripcion ins2= new Inscripcion(12);
        
        c1.addInscripcion(ins2);
        e1.addInscripcion(ins2);
        
        c2.addInscripcion(ins1);
        e1.addInscripcion(ins1);
        
        System.out.println("Academia");
        System.out.println(a);
    }
        
        
    }
    

