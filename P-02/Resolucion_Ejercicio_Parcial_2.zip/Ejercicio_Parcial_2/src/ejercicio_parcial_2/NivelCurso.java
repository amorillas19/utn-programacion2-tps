/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package ejercicio_parcial_2;

/**
 *
 * @author enfer
 */
public enum NivelCurso {
    BASICO,
    INTERMEDIO,
    AVANZADO;
}
