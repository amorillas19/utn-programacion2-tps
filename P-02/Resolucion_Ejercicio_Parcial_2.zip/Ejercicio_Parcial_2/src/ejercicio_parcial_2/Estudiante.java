/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_parcial_2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author enfer
 */
public class Estudiante extends Persona {
    private List<Inscripcion> inscripciones= new ArrayList();

    public Estudiante(int id, String nombre, String email) {
        super(id, nombre, email);
    }

    public List<Inscripcion> getInscripciones() {
        return inscripciones;
    }
    
    
   public void addInscripcion(Inscripcion ins){
       if(ins!=null){
       inscripciones.add(ins);
       ins.setEstudiante(this);
       }
   } 
    
   public void removeInscripcion(Inscripcion ins){
       if(ins!=null){
       inscripciones.remove(ins);
       ins.setEstudiante(null);
       }
   }

    @Override
    public String toString() {
        return super.toString()+"Etudiante{" + "inscripciones=" + inscripciones + '}';
    }
   
   
}
