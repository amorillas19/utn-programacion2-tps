/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_parcial_2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author enfer
 */
public class Instructor extends Persona {
    private EspecialidadInstructor especialidad;
    private List<Curso> cursos=new ArrayList();

    public Instructor( int id, String nombre, String email,EspecialidadInstructor especialidad) {
        super(id, nombre, email);
        this.especialidad = especialidad;
    }

    public EspecialidadInstructor getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(EspecialidadInstructor especialidad) {
        this.especialidad = especialidad;
    }

    public List<Curso> getCursos() {
        return cursos;
    }

   public void addCurso(Curso curso){
       if(curso!=null){
       cursos.add(curso);
       }
   }
    
   public void removeCurso(Curso curso){
       cursos.remove(curso);
   }
    
}
