/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_parcial_2;

import java.time.LocalDate;

/**
 *
 * @author enfer
 */
public class Inscripcion implements Registrable{
private int id;
private LocalDate fecha;
private Estudiante estudiante;
private Curso curso;

    public Inscripcion(int id) {
        this.id = id;
        this.fecha = LocalDate.now();
       
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }



    @Override
    public void registrable() {
        System.out.println("La fecha de inscripcion del estudiante "+estudiante.getNombre()+" se realizo el dia "+fecha);
    }

    @Override
    public String toString() {
        return "Inscripcion{" + "id=" + id + ", fecha=" + fecha + ", estudiante=" + estudiante.getNombre() + ", curso=" + curso.getNombre() + '}';
    }
    
}
