/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_parcial_2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author enfer
 */
public class Curso {
    private int id;
    private String nombre;
    private int duracion;
    private NivelCurso nivel;
    private Academia academia;
    private List<Modulo> modulos= new ArrayList();
    private List<Inscripcion> inscripciones= new ArrayList();

    public Curso(int id, String nombre, int duracion, NivelCurso nivel) {
        this.id = id;
        this.nombre = nombre;
        this.duracion = duracion;
        this.nivel = nivel;
      
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public NivelCurso getNivel() {
        return nivel;
    }

    public void setNivel(NivelCurso nivel) {
        this.nivel = nivel;
    }

    public Academia getAcademia() {
        return academia;
    }

    public void setAcademia(Academia academia) {
        this.academia = academia;
    }

    public List<Modulo> getModulos() {
        return modulos;
    }

    public void addModulo(int id,String titulo, String contenido){
    
        modulos.add(new Modulo(id,titulo,contenido));
    }

    
    public List<Inscripcion> getInscripciones() {
        return inscripciones;
    }

   public void addInscripcion(Inscripcion ins){
   if(ins!=null){
   inscripciones.add(ins);
   ins.setCurso(this);
   }
   }
    
    public void remove(Inscripcion ins){
        inscripciones.remove(ins);
        ins.setCurso(null);
    }

    @Override
    public String toString() {
        return "Curso{" + "id=" + id + ", nombre=" + nombre + ", duracion=" + duracion + ", nivel=" + nivel + ", academia=" + academia.getNombre() + ", modulos=" + modulos + ", inscripciones=" + inscripciones + '}';
    }
    
    
}
