/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ejercicio_parcial_2;

/**
 *
 * @author enfer
 */
public interface Registrable {
    void registrable();
}
